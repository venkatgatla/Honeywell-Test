<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Current Conditions</name>
   <tag></tag>
   <elementGuidId>dac557b7-d295-4585-9d94-fcbb5b4930a9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='__next']/div/header/section[2]/section/section/div[2]/div/ul/ul/li/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>ul.nav-submenu__SubmenuContainer-sc-upp2xz-0.gybbxZ > ul.menu-item__MenuList-sc-1ht3jhe-0.bmdNMI > li.menu-item__MenuListItem-sc-1ht3jhe-1.giAXbn > a.menu-item__Anchor-sc-1ht3jhe-2.eUAkbN</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>98dc6fa0-8668-4c6f-b417-0203a9874542</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>menu-item__Anchor-sc-1ht3jhe-2 eUAkbN</value>
      <webElementGuid>95e0fa73-f8cb-43bc-bac4-a253d419bc2e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://www.flightstats.com/v2/airport-conditions/search</value>
      <webElementGuid>44d052b4-f778-4cbf-b082-18a69df88036</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Current Conditions</value>
      <webElementGuid>cebf69aa-0867-4cd5-a12c-6fd9288788cc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;__next&quot;)/div[@class=&quot;desktop__LayoutWrapper-sc-43d6t8-0 hlRtPs&quot;]/header[@class=&quot;desktop-header__HeaderContainer-sc-1hnb9a6-0 dXtUFP&quot;]/section[@class=&quot;desktop-header__NavRow-sc-1hnb9a6-3 ksnWvB desktop-header__Row-sc-1hnb9a6-1 epLlIv&quot;]/section[@class=&quot;desktop-header__MainNavigation-sc-1hnb9a6-6 jhbgcN&quot;]/section[@class=&quot;hoverable-menu__NavSection-sc-166bj4y-0 jDEfQt&quot;]/div[@class=&quot;menu-heading__HeadingOuter-sc-fepp0s-0 eaNTFv&quot;]/div[@class=&quot;menu-heading__SubmenuOuter-sc-fepp0s-2 jWwjPh&quot;]/ul[@class=&quot;nav-submenu__SubmenuContainer-sc-upp2xz-0 gybbxZ&quot;]/ul[@class=&quot;menu-item__MenuList-sc-1ht3jhe-0 bmdNMI&quot;]/li[@class=&quot;menu-item__MenuListItem-sc-1ht3jhe-1 giAXbn&quot;]/a[@class=&quot;menu-item__Anchor-sc-1ht3jhe-2 eUAkbN&quot;]</value>
      <webElementGuid>c3024e86-83d2-4d82-ae61-4ddf26cca76a</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='__next']/div/header/section[2]/section/section/div[2]/div/ul/ul/li/a</value>
      <webElementGuid>acab6bdb-0275-44c3-aeb1-4051a64e174a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Current Conditions')]</value>
      <webElementGuid>f647a264-a9b4-451f-b793-5f92e25712b5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Airports'])[1]/following::a[1]</value>
      <webElementGuid>c28e42d9-a4bb-49b5-9b0e-41f1f3a6f208</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Alerts'])[1]/following::a[2]</value>
      <webElementGuid>ee500cbf-40a4-45c0-b67d-01758b799806</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Departures and Arrivals'])[1]/preceding::a[1]</value>
      <webElementGuid>88a4b560-ddc4-4dda-bb32-e5e180cf7dc9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Airport Delays'])[1]/preceding::a[2]</value>
      <webElementGuid>be97bb06-b133-4844-9d1a-4f0aa9f7fc79</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Current Conditions']/parent::*</value>
      <webElementGuid>29b9f6d4-86b9-458f-bcfd-840dfae8b075</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://www.flightstats.com/v2/airport-conditions/search')]</value>
      <webElementGuid>7254f7da-04ad-4eaf-bab0-5e89ccbf079d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/ul/ul/li/a</value>
      <webElementGuid>ab1c36df-eebf-4721-8463-c7125971f1e7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://www.flightstats.com/v2/airport-conditions/search' and (text() = 'Current Conditions' or . = 'Current Conditions')]</value>
      <webElementGuid>b96d9b1b-9970-4efd-a313-38585952fb74</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
