<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_Arrived Yesterday</name>
   <tag></tag>
   <elementGuidId>12ae3814-daaf-41f0-a0e8-c5de879849b7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='focusedMenuItem-AmericanAirlines2345']/div/p[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>p.search-list-item__SubtextResultWrapper-sc-1d9qcg9-1.iOOtzX</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>464d40f4-8633-43f3-849f-9d32d15ce1f6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>search-list-item__SubtextResultWrapper-sc-1d9qcg9-1 iOOtzX</value>
      <webElementGuid>3a258f9d-0d6b-4ccf-b805-84fac2d7e028</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>label</name>
      <type>Main</type>
      <value>Arrived Yesterday</value>
      <webElementGuid>5199abbe-3c82-4189-869b-931ef29a5fc9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Arrived Yesterday</value>
      <webElementGuid>7c1f3a3a-b8db-4e03-9fe9-3a19e7da2272</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;focusedMenuItem-AmericanAirlines2345&quot;)/div[@class=&quot;search-list-item__InnerWrapper-sc-1d9qcg9-6 iykGEB&quot;]/p[@class=&quot;search-list-item__SubtextResultWrapper-sc-1d9qcg9-1 iOOtzX&quot;]</value>
      <webElementGuid>f436fec6-9ae3-46bd-9324-ad991dd31bea</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='focusedMenuItem-AmericanAirlines2345']/div/p[2]</value>
      <webElementGuid>bdca18cd-a2d1-46f8-b170-e0fa8c588ff7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Track a Flight'])[1]/following::p[2]</value>
      <webElementGuid>df00edd5-19e3-4ccd-80ef-b196d29ffd52</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='My Account'])[1]/following::p[2]</value>
      <webElementGuid>6fd93bc7-ad7f-47b5-8823-06beb4b0e7f5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='DFW'])[1]/preceding::p[1]</value>
      <webElementGuid>3695293d-1c2b-4b1a-bf6e-15287bd9810f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Dallas'])[1]/preceding::p[1]</value>
      <webElementGuid>9592d149-6954-4ffe-876b-815cfa06a4b6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Arrived Yesterday']/parent::*</value>
      <webElementGuid>63e9d940-eef9-4bd1-9053-525095516fbe</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//p[2]</value>
      <webElementGuid>941c4d37-f63e-4309-8a82-c7f0a98c2fd3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = 'Arrived Yesterday' or . = 'Arrived Yesterday')]</value>
      <webElementGuid>68a493da-537e-4de1-b078-deec6b78568f</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
