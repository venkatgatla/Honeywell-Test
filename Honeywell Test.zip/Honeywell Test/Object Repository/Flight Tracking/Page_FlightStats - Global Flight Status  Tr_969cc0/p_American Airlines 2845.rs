<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_American Airlines 2845</name>
   <tag></tag>
   <elementGuidId>59917977-133a-4092-b2fa-c682c707b6bb</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='focusedMenuItem-AmericanAirlines2845']/div/p</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>p.sc-eqIVtm.ksMBUk</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>fa4bee84-ed91-4125-9434-a9a1fe6ef15c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>sc-eqIVtm ksMBUk</value>
      <webElementGuid>2274eda6-1870-421e-9829-abd242524483</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>label</name>
      <type>Main</type>
      <value>American Airlines 2845</value>
      <webElementGuid>4598464d-1392-4748-b3a1-573ae1a5231c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>American Airlines 2845</value>
      <webElementGuid>5ce5877f-20a8-4966-aa55-31fdefd54eb3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;focusedMenuItem-AmericanAirlines2845&quot;)/div[@class=&quot;sc-TOsTZ bAZHtp&quot;]/p[@class=&quot;sc-eqIVtm ksMBUk&quot;]</value>
      <webElementGuid>a6ed1ebb-38e2-4c4d-8e70-1ab04610efb6</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='focusedMenuItem-AmericanAirlines2845']/div/p</value>
      <webElementGuid>28cfeb12-f927-4682-b402-49560a9330ea</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Track a Flight'])[1]/following::p[2]</value>
      <webElementGuid>af7e742e-48a8-46cd-b0dd-dfc0ce6d5c4f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='FlightStats Serves the Needs of On-the-go Travelers'])[1]/following::p[2]</value>
      <webElementGuid>f78f41fe-39a3-4f70-b96c-a1f6024c7da6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='DFW'])[1]/preceding::p[2]</value>
      <webElementGuid>d79b8188-6ab0-441e-9523-de852fea5eeb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Dallas'])[1]/preceding::p[2]</value>
      <webElementGuid>5949d531-e51f-48cf-8a70-1a0aa2573824</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='American Airlines 2845']/parent::*</value>
      <webElementGuid>ceb6b89e-c9c8-4684-9334-85bb1e31a8d6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/p</value>
      <webElementGuid>c0eb9f19-ff3d-46f3-a6a1-2fc60ecdd2e1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = 'American Airlines 2845' or . = 'American Airlines 2845')]</value>
      <webElementGuid>b9389687-2d29-4ddd-b6a4-d126986aa9a8</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
