<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Advanced Search</name>
   <tag></tag>
   <elementGuidId>eca269c9-7f95-4a3a-9d59-3f3d6640f496</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='content']/div/div/main/div/div/div/div/div/div/section/div/div/form/div[2]/div[2]/a/button/div/span[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>button.flight-tracker-adv-search-button > div > span:nth-of-type(2)</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>8002abde-1ffe-448b-9f38-be9c11aea097</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Advanced Search</value>
      <webElementGuid>821a3fc6-0272-4cdd-b0c1-438df3144606</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;content&quot;)/div[1]/div[@class=&quot;content-holder&quot;]/main[@class=&quot;container&quot;]/div[@class=&quot;homepage-container&quot;]/div[@class=&quot;homepage-section&quot;]/div[@class=&quot;sc-jWBwVP htDcKw&quot;]/div[1]/div[1]/div[@class=&quot;unified-flight-tracker-search-feature&quot;]/section[@class=&quot;FlightSearch&quot;]/div[@class=&quot;flight-search-container&quot;]/div[@class=&quot;fs-search&quot;]/form[1]/div[@class=&quot;flight-tracker-smart-search-buttons-group&quot;]/div[@class=&quot;flight-tracker-smart-search-button&quot;]/a[1]/button[@class=&quot;flight-tracker-adv-search-button&quot;]/div[1]/span[2]</value>
      <webElementGuid>1a176444-99c9-40b4-8383-f4be45cb5d44</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='content']/div/div/main/div/div/div/div/div/div/section/div/div/form/div[2]/div[2]/a/button/div/span[2]</value>
      <webElementGuid>9055454f-d9d9-4626-baec-df8c232e7991</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Search'])[1]/following::span[2]</value>
      <webElementGuid>a9896e49-c8d0-4954-9e65-f0ff4b2e3cd4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Track a Flight'])[1]/following::span[4]</value>
      <webElementGuid>1292cad3-1aba-4b69-9324-703e3a3428f9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Features of the Site'])[1]/preceding::span[1]</value>
      <webElementGuid>5208fa45-1197-4235-9944-a6ab02e9fdef</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Welcome to FlightStats'])[1]/preceding::span[1]</value>
      <webElementGuid>8ce09275-f941-436e-9dac-84082d442aea</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Advanced Search']/parent::*</value>
      <webElementGuid>d3e671d7-2765-47b3-8a16-e236d3370a53</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//button/div/span[2]</value>
      <webElementGuid>ad74eb34-31cc-41e1-bdef-9e97770925e1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Advanced Search' or . = 'Advanced Search')]</value>
      <webElementGuid>2c7e59ba-c5c2-4a78-b923-7d2f730ef944</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
