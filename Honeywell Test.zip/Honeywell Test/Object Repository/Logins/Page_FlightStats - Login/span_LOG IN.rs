<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_LOG IN</name>
   <tag></tag>
   <elementGuidId>8556a907-52b3-4ddf-8976-079f33e77058</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='content']/div/div/main/div/div/div/div[2]/div/form/div[2]/button/div/span[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.innerPadding > button[type=&quot;button&quot;] > div > span:nth-of-type(2)</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>f9b30529-db8b-4a3f-a324-64ea1a5534c9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>LOG IN</value>
      <webElementGuid>e083190e-bf86-4531-a6c3-489812db22d1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;content&quot;)/div[1]/div[@class=&quot;content-holder&quot;]/main[@class=&quot;container&quot;]/div[@class=&quot;LoginContainer&quot;]/div[@class=&quot;sharedAccountFormContainer&quot;]/div[@class=&quot;sc-jWBwVP bpetZw&quot;]/div[2]/div[@class=&quot;innerContent&quot;]/form[1]/div[@class=&quot;innerPadding&quot;]/button[1]/div[1]/span[2]</value>
      <webElementGuid>54086a70-4be4-422b-830d-5570bfa46e86</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='content']/div/div/main/div/div/div/div[2]/div/form/div[2]/button/div/span[2]</value>
      <webElementGuid>37fa0586-fe7f-4c3c-8cf9-8572b83981b2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Forgot Password?'])[1]/following::span[2]</value>
      <webElementGuid>8bfe2cff-0cea-4b5c-bd09-d7ebc59324ad</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Remember Me'])[1]/following::span[2]</value>
      <webElementGuid>7baa79b0-de66-484a-8c48-ba8885faa9cd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Create a New Account'])[1]/preceding::span[1]</value>
      <webElementGuid>0c7c54ee-4d4b-40f2-851a-4142b72823b1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Cookie Settings'])[1]/preceding::span[2]</value>
      <webElementGuid>c1b27bd3-6058-4a6c-bf4b-d781a7c5f4c8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='LOG IN']/parent::*</value>
      <webElementGuid>dfc8b934-b350-4dcc-94d4-1a05992b22fb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//form/div[2]/button/div/span[2]</value>
      <webElementGuid>4d7ba0c3-2bd3-483c-8993-e02500f8c6f3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'LOG IN' or . = 'LOG IN')]</value>
      <webElementGuid>46b39256-1b1a-40da-a40d-32e34ea1017a</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
